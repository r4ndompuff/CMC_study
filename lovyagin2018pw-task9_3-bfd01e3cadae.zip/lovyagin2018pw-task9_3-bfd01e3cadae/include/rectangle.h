#pragma once

#include <iostream>
#include "base.h"

using namespace::std;

class Rectangle : public BasicShape		// <- Main Class
{
public:
	Rectangle();	// Constructor
	Rectangle(long int aWidth, long int aLength);  // Parameter Constructor
	~Rectangle();	// Destructor

	// Setters
	void setWidth(long int aWidth);
	void setLength(long int aLength);

	// Getters
	long int getWidth() const;
	long int getLength() const;

	// Methods
	double calculateArea() override;

protected:
	long int width, length;
};

