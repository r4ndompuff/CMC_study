#pragma once

#include <iostream>
#include "base.h"

using namespace::std;

class Circle : public BasicShape // <- Main Class
{
public:

	// Constructors
	Circle();
	Circle(long int aCenterX, long int aCenterY, double aRadius);
	~Circle();

	// Setters
	void setCenterX(long int aCenterX);
	void setCenterY(long int aCenterY);
	void setRadius(double aRadius);

	// Getters
	long int getCenterX() const;
	long int getCenterY() const;
	double getRadius() const;

	// Method
	double calculateArea() override;


protected:
	long int centerX, centerY;
	double radius;
};


