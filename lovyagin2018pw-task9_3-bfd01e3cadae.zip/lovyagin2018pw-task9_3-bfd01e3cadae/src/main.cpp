#include <iostream>
#include <iomanip>
#include <cstdlib>
#include "../include/base.h"
#include "../include/circle.h"
#include "../include/rectangle.h"
#include "../include/cut.h"

using namespace::std;

string help(
                "                           \\CIRCLE ------- Create circle\n"
                "                           \\REKT --------- Create rectangle :p\n"
                "                           \\CUT ---------- Create cutted figure\n"
                "                           \\PRCRCL ------- Print circle area\n"
                "                           \\PRREKT ------- Print rectangle area :p\n"
                "                           \\PRCUT -------- Print cutted area of figure\n"
                "                           \\HELP --------- Help\n"
                "                           \\EXIT --------- Leave\n\n> "
);

void newline() {
    std::cout << "\n";
}

int main() {
	Circle cir;
	Rectangle rec;
	cut cu;
    bool flag = true;
    cout << "Use '\\HELP' for more information\n\n> ";
    while (true) {
        string s;
        getline(std::cin, s);  
        if (s == "\\HELP") {
            cout << help;
        }
        else if (s == "\\CIRCLE") {
        	flag = false;
        	double rad;
            cout << "Enter radius:\n>>> ";
            cin >> rad;
            Circle td(0,0,rad);
            cir = td;
        }
        else if (s == "\\REKT") {
            flag = false;
        	long int len;
        	long int wid;
            cout << "Enter length:\n>>> ";
            cin >> len;
            cout << "Enter width:\n>>> ";
            cin >> wid;
            Rectangle td(len,wid);
            rec = td;
        }
        else if (s == "\\CUT") {
            flag = false;
        	long int len;
        	long int wid;
        	long int rad;
            cout << "Enter length:\n>>> ";
            cin >> len;
            cout << "Enter width:\n>>> ";
            cin >> wid;
            cout << "Enter radius:\n>>> ";
            cin >> rad;
            cut td(wid,len,rad);
            cu = td;
        }
        else if (s == "\\PRCRCL") {
            cout << cir.calculateArea() << "\n\n> ";
        }
        else if (s == "\\PRREKT") {
            cout << rec.calculateArea() << "\n\n> ";
        }
        else if (s == "\\PRCUT") {
            cout << cu.calculateArea() << "\n\n> ";
        }
        else if (s == "\\EXIT") {
            break;
        }
        else if (flag)
            cout << "No such command.\n\n> ";
        else {
            flag = true;
            cout << "\n> ";
        }
    }
	cout << "Circle" << endl;
	cout << "Coordinate of the x axis of the circle's center: " << cir.getCenterX() << endl;
	cout << "Coordinate of the y axis of the circle's center: " << cir.getCenterY() << endl;
	cout << "The area of a circle with a " << cir.getRadius() << " radius is: " << cir.calculateArea() << endl;
	cout << "\nRectangle" << endl;
	cout << "The area of a rectangle with a width of " << rec.getWidth() << " and a " << rec.getLength() << " of length is: " << rec.calculateArea() << endl;

	return 0;

}