#include <iostream>
#include "../include/base.h"
#include "../include/circle.h"
#include "../include/cut.h"
#include "../include/cut.h"


using namespace::std;

// Constructors
cut::cut() : Rectangle(), Circle()
{
	setWidth(0);
	setLength(0);
	setRadius(0);
}

// Parameter Constructor
cut::cut(long int aWidth, long int aLength, double aRadius) : Rectangle(), Circle()
{
	setWidth(aWidth);
	setLength(aLength);
	setRadius(aRadius);
}

// Destructor
cut::~cut()
{
	//cout << "Destroying cut..." << endl;
}

// Method
double cut::calculateArea()
{
	double area;
	area = Rectangle::length * Rectangle::width - 3.14159 * Circle::radius * Circle::radius;
	return area;
}
