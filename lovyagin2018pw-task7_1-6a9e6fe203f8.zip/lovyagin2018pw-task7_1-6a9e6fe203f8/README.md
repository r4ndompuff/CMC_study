# Task7_1
Chosen tasks: Calc 1 and chat 2+3.

Assembly process: make all

Startup process: ./server -- ./client [127.0.0.1]

Description: Client-server
			 
Used libraries: check in the files.

Additional information: For this tasks I was using help of the internet. Admin pass - "toor".