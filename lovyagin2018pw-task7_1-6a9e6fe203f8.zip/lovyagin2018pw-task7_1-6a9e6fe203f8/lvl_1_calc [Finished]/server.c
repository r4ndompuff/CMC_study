#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define BUFLEN  40

int int_or_not(char *letter) {
int i = 0;
    while ((letter[i] != '\n') && (letter[i] != '\0')) {
        if ((letter[i] == '0') || (letter[i] == '1') || (letter[i] == '2') || (letter[i] == '3') || (letter[i] == '4') || (letter[i] == '5') || (letter[i] == '6') || (letter[i] == '7') || (letter[i] == '8') || (letter[i] == '9'))
            i++;
        else
            return 0;
    }
    return 1;
}

int fitting_number(char *letter, int i) {
    int ans = 0;
    while ((letter[i] != '\n') && (letter[i] != '\0')) {
        ans = ans * 10 + ((int)letter[i] - '0');
        i++;
    }
    return ans;
}

int main()
{
    int sock, listener;
    struct sockaddr_in addr;
    char buf[BUFLEN];
    int bytes_read;
    int quitting;
    int adding_number = 0;

    listener = socket(AF_INET, SOCK_STREAM, 0);
    if(listener < 0)
    {
        perror("Socket error.");
        exit(1);
    }
    
    addr.sin_family = AF_INET;
    addr.sin_port = htons(3425);
    addr.sin_addr.s_addr = INADDR_ANY;
    if(bind(listener, (struct sockaddr *)&addr, sizeof(addr)) < 0)
    {
        perror("Bind error.");
        exit(2);
    }

    listen(listener, 1);
    
    while(1)
    {
        sock = accept(listener, 0, 0);
        if(sock < 0)
        {
            perror("Accept error.");
            exit(3);
        }
        
        switch(fork())
        {
        case -1:
            perror("Fork error.");
            break;
        case 0:
            close(listener);
            while(1)
            {   
                bytes_read = recv(sock, buf, BUFLEN, 0);
                if(bytes_read <= 0) break;
                quitting = (!strcmp(buf, "\\-"));
                printf("Server: received from client: %s \n", buf);
                if (quitting)
                    strcpy(buf, "Quitting now!");
                else if (strstr(buf, "\\+") != 0) {
                    adding_number = fitting_number(buf, 3);
                    strcpy(buf, "Your number is saved!");
                }
                else if (strstr(buf, "\\?") != 0)
                    sprintf(buf, "%d", adding_number);
                else if (int_or_not(buf))
                    sprintf(buf, "%d", fitting_number(buf,0)+adding_number);
                else
                    strcpy(buf, "Wrong command, try again!");
                send(sock, buf, bytes_read, 0);
            }

            close(sock);
            _exit(0);
            
        default:
            close(sock);
        }
    }
    
    close(listener);

    return 0;
}