#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define BUFLEN  40

char message[] = "Hello there!\n";

int main()
{
    int quitting;
    char buf[BUFLEN];
    int sock;
    struct sockaddr_in addr;

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if(sock < 0)
    {
        perror("socket");
        exit(1);
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(3425); // или любой другой порт...
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if(connect(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0)
    {
        perror("connect");
        exit(2);
    }
    printf("Type the string: ");
    while (gets(buf)) {
        send(sock, buf, BUFLEN, 0);
        quitting = (!strcmp(buf, "\\-"));
        recv(sock, buf, BUFLEN, 0);
        printf("Client: server answered: %s\n", buf);
        if (quitting) break;
        printf("Type the string: ");
    }
    close(sock);

    return 0;
}