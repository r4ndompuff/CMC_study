# Task4_2
Chosen tasks: model language interpreter

Assembly process: make

Startup process: make run

Description: Use 'make help'

Used libraries: iostream, stack, fstream, exception, string.h, ctype.h, stdlib.h

Additional information: For this tasks I was using help of the internet and Egor Guguchkin (and previous year).