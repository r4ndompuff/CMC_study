# Task8_2
Chosen tasks: matrix 4.1.

Assembly process: make

Startup process: make run

Description: Use make help or \HELP in program.
			 
Used libraries: iostream, cstring, cstdlib.

Additional information: For this tasks I was using help of the internet and Egor Guguchkin.